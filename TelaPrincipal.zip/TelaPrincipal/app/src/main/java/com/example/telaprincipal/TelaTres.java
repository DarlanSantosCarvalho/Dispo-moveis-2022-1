package com.example.telaprincipal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TelaTres extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_tres);
    }
}